from flask import Flask, request, flash, redirect, url_for, render_template
from app.models.missao import Missao  
from app import app, db
from datetime import datetime
from datetime import date

@app.route('/atualizar_missao/<int:id>', methods = ['GET', 'POST'])
def atualizar_missao_route(id):
    missao = Missao.query.get_or_404(id)

    if request.method == 'POST':
        missao.nomeMissao = request.form.get('nomeMissao')
        data_lancamento_str = request.form.get('dataLancamento')
        if data_lancamento_str:
            missao.dataLancamento = datetime.strptime(data_lancamento_str, '%Y-%m-%d').date()
        missao.destino = request.form.get('destino')
        missao.estadoMissao = request.form.get('estadoMissao')
        missao.tripulacao = request.form.get('tripulacao')
        missao.cargaUtil = request.form.get('cargaUtil')
        missao.duracaoMissao = request.form.get('duracaoMissao')
        missao.custoMissao = request.form.get('custoMissao')
        missao.statusMissao = request.form.get('statusMissao')
        
        try:
            db.session.commit()
            flash('Missão atualizada com sucesso!', 'success')
            return redirect(url_for('listar_missoes_route'))  
        except Exception as e:
            print(e)
            db.session.rollback()
            flash(f'Erro ao atualizar missão: {e}', 'error')

    return render_template('atualizar_missao.html', missao = missao)
