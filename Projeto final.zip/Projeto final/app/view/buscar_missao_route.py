from datetime import datetime
from datetime import date
from flask import Flask, request, flash, redirect, url_for, render_template
from app.models.missao import Missao
from app import app, db



@app.route('/buscar_missao', methods=['GET'])
def buscar_missao_route():
    data_lancamento_str = request.args.get('dataLancamento')
    
    missoes = []
    if data_lancamento_str:
        try:
            data_lancamento = datetime.strptime(data_lancamento_str, '%Y-%m-%d').date()
            missoes = Missao.query.filter_by(dataLancamento=data_lancamento).all()
        except ValueError:
            pass 

    return render_template('resultados_pesquisa.html', missoes=missoes)
