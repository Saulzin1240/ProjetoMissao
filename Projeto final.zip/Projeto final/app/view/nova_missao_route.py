from flask import Flask, request, flash, redirect, url_for, render_template
from app.models.missao import Missao  
from app import app, db
from datetime import datetime
from datetime import date


@app.route('/nova_missao', methods=['GET', 'POST'])
def nova_missao_route():
    if request.method == 'POST':
        dados_missao = {
            'nomeMissao': request.form.get('nomeMissao'),
            'dataLancamento': request.form.get('dataLancamento'),
            'destino': request.form.get('destino'),
            'estadoMissao': request.form.get('estadoMissao'),
            'tripulacao': request.form.get('tripulacao'),
            'cargaUtil': request.form.get('cargaUtil'),
            'duracaoMissao': request.form.get('duracaoMissao'),
            'custoMissao': request.form.get('custoMissao'),
            'statusMissao': request.form.get('statusMissao'),
        }

        
        if not dados_missao['nomeMissao']:  
            flash("Nome da missão é obrigatório!")
            return redirect(url_for('nova_missao_route'))  
        
        try:
            
            resultado = Missao.nova_missao(dados_missao)

        
            if resultado:  
                flash("Missão criada com sucesso!")
            else:
                flash("Erro ao criar missão.")
        
        except Exception as e:
            flash(f"Ocorreu um erro: {e}")
            return redirect(url_for('nova_missao_route'))  
        return redirect(url_for('listar_missoes_route'))  

    return render_template('nova_missao.html') 

