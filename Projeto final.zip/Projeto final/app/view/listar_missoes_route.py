from flask import render_template
from app import app, db
from app.models.missao import Missao

@app.route('/listar_missoes', methods=['GET'])
def listar_missoes_route():
    missoes = Missao.mostrar_missoes()  
    return render_template('listar_missoes.html', missoes = missoes)
