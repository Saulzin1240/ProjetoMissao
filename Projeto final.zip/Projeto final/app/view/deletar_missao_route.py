from flask import Flask, request, flash, redirect, url_for, render_template
from app.models.missao import Missao  
from app import app, db

@app.route('/deletar_missao/<int:id>', methods=['POST'])
def deletar_missao_route(id):
    missao = Missao.query.get_or_404(id)

    try:
        db.session.delete(missao)
        db.session.commit()
        flash('Missão deletada com sucesso!', 'success')
    except Exception as e:
        print(e)
        db.session.rollback()
        flash(f'Erro ao deletar missão: {e}', 'error')

    return redirect(url_for('listar_missoes_route'))