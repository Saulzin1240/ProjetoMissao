from flask_sqlalchemy import SQLAlchemy
from app import db
from datetime import datetime
from datetime import date

class Missao(db.Model):
    __tablename__= "Missão"
    __table_args__= {"sqlite_autoincrement":True}
    id = db.Column(db.Integer, primary_key=True)
    nomeMissao = db.Column(db.String(255))
    dataLancamento = db.Column(db.Date)
    destino = db.Column(db.String(20))
    estadoMissao = db.Column(db.String(20))
    tripulacao = db.Column(db.String(50))
    cargaUtil = db.Column(db.String(100))
    duracaoMissao = db.Column(db.String(100))
    custoMissao = db.Column(db.Float)
    statusMissao = db.Column(db.String(100))
    
    
    def __init__(self, nomeMissao, dataLancamento, destino, estadoMissao, 
    tripulacao, cargaUtil, duracaoMissao, custoMissao, statusMissao):
        self.nomeMissao = nomeMissao
        self.dataLancamento = date.fromisoformat(dataLancamento)
        self.destino = destino
        self.estadoMissao = estadoMissao
        self.tripulacao = tripulacao
        self.cargaUtil = cargaUtil
        self.duracaoMissao = duracaoMissao
        self.custoMissao = custoMissao
        self.statusMissao = statusMissao   
    
    @classmethod
    def nova_missao(cls, dados):
        print(dados)
        try:
            nova_missao = cls(
                nomeMissao=dados['nomeMissao'],
                dataLancamento=dados['dataLancamento'],
                destino=dados['destino'],
                estadoMissao=dados['estadoMissao'],
                tripulacao=dados['tripulacao'],
                cargaUtil=dados['cargaUtil'],
                duracaoMissao=dados['duracaoMissao'],
                custoMissao=dados['custoMissao'],
                statusMissao=dados['statusMissao']
            )
            db.session.add(nova_missao)
            db.session.commit()
            return "Nova missão adicionada com sucesso!"
        except Exception as e:
            print(e)
            db.session.rollback()  
            return f"Não foi possível adicionar uma nova missão: {str(e)}"
    
    @classmethod
    def mostrar_missoes(cls):
        missoes = cls.query.order_by(cls.dataLancamento.desc()).all()        
        return[ 
            {
                'id': missao.id,
                'nomeMissao': missao.nomeMissao,
                'destino': missao.destino,
                'estadoMissao': missao.estadoMissao,
                'dataLancamento': missao.dataLancamento.strftime('%Y-%m-%d')
            }
            for missao in missoes
        ]   
            
    @classmethod
    def atualizar_missao(cls, id, nomeMissao=None, dataLancamento=None, 
    destino=None, estadoMissao=None, tripulacao=None, cargaUtil=None, duracaoMissao=None, 
    custoMissao=None, statusMissao=None):
        missao = cls.query.get(id)
        if missao:
            if nomeMissao is not None:
                missao.nomeMissao = nomeMissao
            if dataLancamento is not None:
                missao.dataLancamento = dataLancamento
            if destino is not None:
                missao.destino = destino
            if estadoMissao is not None:
                missao.estadoMissao = estadoMissao
            if tripulacao is not None:
                missao.tripulacao = tripulacao
            if cargaUtil is not None:
                missao.cargaUtil = cargaUtil
            if duracaoMissao is not None:
                missao.duracaoMissao = duracaoMissao
            if custoMissao is not None:
                missao.custoMissao = custoMissao
            if statusMissao is not None:
                missao.statusMissao = statusMissao
            
            db.session.commit()
            return "Missão atualizada com sucesso!"
        else:
            return "Missão não encontrada!"
            
    @classmethod
    def excluir_missao(cls, id):
        missao = cls.query.get(id)
        if missao:
            db.session.delete(missao)
            db.session.commit()
            return "Missão excluida com sucesso!"
        else:
            return "Missão não encontrada!"
        
        


        

    
