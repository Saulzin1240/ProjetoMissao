from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///missao.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'pequenoelastico'

db = SQLAlchemy(app)


from app.view.nova_missao_route import nova_missao_route
from app.view.listar_missoes_route import listar_missoes_route
from app.view.atualizar_missao_route import atualizar_missao_route
from app.view.deletar_missao_route import deletar_missao_route
from app.view.buscar_missao_route import buscar_missao_route